<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<doc>
  <msg>{{ $msg }}</msg>
</doc>

