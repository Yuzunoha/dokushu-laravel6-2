<tr>
  <td>{{ $record->title }}</td>
  <td>{{ $record->price }}円</td>
  <td>{{ $record->publisher }}</td>
  <td>{{ $record->published }}</td>
</tr>