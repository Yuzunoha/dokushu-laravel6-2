@extends('layouts.base')
@section('title', 'クッキー')
@section('main')
  <p>{{ $app_title }}</p>
@endsection