@extends('layouts.base')
@section('title', 'クッキー')
@section('main')
  <p>クッキーを保存しました</p>
@endsection