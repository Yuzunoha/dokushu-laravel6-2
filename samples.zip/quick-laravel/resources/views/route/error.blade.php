@extends('layouts.base')
@section('title', 'フォールバックルート')
@section('main')
  <p class="text-danger">{{ '該当するページが見つかりませんでした。' }}</p>
@endsection