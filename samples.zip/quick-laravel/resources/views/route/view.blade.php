@extends('layouts.base')
@section('title', 'アクションの省略')
@section('main')
  <p>{{ $name }}</p>
@endsection